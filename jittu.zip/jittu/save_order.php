<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
session_start();
include 'db.php';
$uid = $_SESSION["uid"];
$sql = "SELECT * FROM cart WHERE user_id = '$uid'";
$run_query = mysqli_query($con, $sql);
while ($row = mysqli_fetch_array($run_query)) {
    mysqli_query($con, "INSERT INTO `orders`(`u_id`, `p_id`, `qty`) VALUES ('$uid','".$row["p_id"]."','".$row["qty"]."')");
}

echo "<script>alert('A order has been successfully!')</script>";
 $sql = "delete from cart WHERE user_id = '$uid'";
 mysqli_query($con, $sql);
                        
                                json_decode(file_get_contents("https://smsapi.engineeringtgr.com/send/?Mobile=7000610729&Password=akkushwa&Message=".urlencode("You are order done..")."&To=".urlencode($_SESSION["mobile"])."&Key=akkushuPxr5pzqSj3tfNwARIsdV") ,true);
	 
                                echo "<script>window.open('index.php?profile.php','_self')</script>";
           