package cms;

import cms.views.MainFrame;

public class Main {

	private Main() {
	}

	public static void main(String[] args) {
		new MainFrame();
	}

}
