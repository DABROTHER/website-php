<!DOCTYPE html>
<html>
	<head>
           		<meta charset="UTF-8">
		<title>Jittu Mobile Shop, Satna</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<style>
             	@media screen and (max-width:480px){
				#search{width:80%;}
				#search_btn{width:30%;float:right;margin-top:-32px;margin-right:10px;}
			}
		</style>
                
                   <!--###############################################-->
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Smart Shop Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<link href="ass/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<!-- pignose css -->
<link href="ass/pignose.layerslider.css" rel="stylesheet" type="text/css" media="all" />


<!-- //pignose css -->
<link href="ass/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- js -->
<script type="text/javascript" src="as/jquery-2.1.4.min.js"></script>
<!-- //js -->
<!-- cart -->
	<script src="as/simpleCart.min.js"></script>
<!-- cart -->
<!-- for bootstrap working -->
	<!--<script type="text/javascript" src="js/bootstrap-3.1.1.min.js"></script>-->
<!-- //for bootstrap working -->
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Lato:400,100,100italic,300,300italic,400italic,700,900,900italic,700italic' rel='stylesheet' type='text/css'>
<script src="as/jquery.easing.min.js"></script>
                <!--################-->
                
                

	</head>
<body>
    
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- soft -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-6269903308849176"
     data-ad-slot="5606622772"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>

    <div class="navbar navbar-inverse navbar-fixed-top" style="background:#38373C">
		<div class="container-fluid">	
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#collapse" aria-expanded="false">
					<span class="sr-only">navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
				
                                 <div class="top_nav_left">
			<div class="cart box_1">
						<a href="#">
							<h3> <div class="total">
								<!--<i class="glyphicon glyphicon-shopping-cart" aria-hidden="true"></i>-->
								<!--<span class="simpleCart_total"></span>-->
                                                                <font color="#0c0000">JITTU Mobile Shop, Satna</font></div>
								
							</h3>
						</a>
						<!--<p><a href="javascript:;" class="simpleCart_empty"></a></p>-->
						
			</div>	
		</div>
		<div class="clearfix"></div>

			</div>
		<div class="collapse navbar-collapse" id="collapse">
			<ul class="nav navbar-nav">
				<li><a href="index.php"><font color="white"><span class="glyphicon glyphicon-home"></span>Home</font></a></li>
                                <li><a href="Admin_area/login.php"><font color="white"><span class="glyphicon glyphicon-modal-window"></span>Admin</font></a></li>
				<!--<li style="width:300px;left:10px;top:10px;"><input type="text" class="form-control" id="search"></li>-->
				<!--<li style="top:10px;left:20px;"><button class="btn btn-primary" id="search_btn">Search</button></li>-->
			</ul>
			<ul class="nav navbar-nav navbar-right">
<!--				<li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="glyphicon glyphicon-shopping-cart"></span>Cart<span class="badge">0</span></a>
					<div class="dropdown-menu" style="width:400px;">
						<div class="panel panel-success">
							<div class="panel-heading">
								<div class="row">
									<div class="col-md-3">Sl.No</div>
									<div class="col-md-3">Product Image</div>
									<div class="col-md-3">Product Name</div>
									<div class="col-md-3">Price in ₹.</div>
								</div>
							</div>
							<div class="panel-body"></div>
							<div class="panel-footer"></div>
						</div>
					</div>
				</li>-->
				<li><a href="#" class="dropdown-toggle" data-toggle="dropdown"><font color="white"><span class="glyphicon glyphicon-user"></span>SignIn</font></a>
					<ul class="dropdown-menu">
						<div style="width:300px;" style="background:#38373C">
							<div class="panel panel-primary" style="background:#38373C">
								<div class="panel-heading" style="background:#38373C">Login</div>
								<div class="panel-heading" style="background:#38373C">
									<label for="email">Email</label>
									<input type="email" class="form-control" id="email" name="Email" required/>
									<label for="email">Password</label>
                                                                        <input type="password" class="form-control" id="password" name="Password" required/>
									<p><br/></p>
									<!--<a href="#" style="color:white; list-style:none;">Forgotten Password</a>-->
                                                                        <input type="submit" class="btn btn-success" style="float:right; background:#FDA30E" id="login" value="Login">
								</div>
								<div class="panel-footer" id="e_msg"></div>
							</div>
						</div>
					</ul>
				</li>
				<!--<li><a href="customer_registration.php"><font color="white"><span class="glyphicon glyphicon-user"></span>SignUp</font></a></li>-->
			</ul>
		</div>
	</div>
        
</div>	

    
    

<!--########################################-->
<!-- //banner-top -->
<!-- banner -->
<!-- //banner-top -->
<!-- banner -->
<!--<br><br><br>-->
<!--<div class="banner-grid">
	<div id="visual">
			<div class="slide-visual">
				 Slide Image Area (1000 x 424) 
				<ul class="slide-group">
					<li><img class="img-responsive" src="images/baa1_1.jpg" alt="Dummy Image" /></li>
					<li><img class="img-responsive" src="images/baa2_1.jpg" alt="Dummy Image" /></li>
					<li><img class="img-responsive" src="images/baa3_1.jpg" alt="Dummy Image" /></li>
				</ul>

				 Slide Description Image Area (316 x 328) 
				<div class="script-wrap">
					<ul class="script-group">
						<li><div class="inner-script"><img class="img-responsive" src="images/baa1_1.jpg" alt="Dummy Image" /></div></li>
						<li><div class="inner-script"><img class="img-responsive" src="images/baa2_1.jpg" alt="Dummy Image" /></div></li>
						<li><div class="inner-script"><img class="img-responsive" src="images/baa3_1.jpg" alt="Dummy Image" /></div></li>
					</ul>
					<div class="slide-controller">
						<a href="#" class="btn-prev"><img src="images/btn_prev.png" alt="Prev Slide" /></a>
						<a href="#" class="btn-play"><img src="images/btn_play.png" alt="Start Slide" /></a>
						<a href="#" class="btn-pause"><img src="images/btn_pause.png" alt="Pause Slide" /></a>
						<a href="#" class="btn-next"><img src="images/btn_next.png" alt="Next Slide" /></a>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
		</div>
	<script type="text/javascript" src="as/pignose.layerslider.js"></script>
	<script type="text/javascript">
	//<![CDATA[
		$(window).load(function() {
			$('#visual').pignoseLayerSlider({
				play    : '.btn-play',
				pause   : '.btn-pause',
				next    : '.btn-next',
				prev    : '.btn-prev'
			});
		});
	//]]>
	</script>

</div>
##################################################-->

    

	
	<p><br/></p>
        <p><br/></p>
        <p><br/></p><p><br/></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="signup_msg">
				<!--Alert from signup form-->
			</div>
			<div class="col-md-2"></div>
		</div>
            <div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8">
				<div class="panel panel-primary" style="background: #38373C">
                                    <div class="panel-heading" style="background: #FDA30E">
                                        <center> Customer SignUp Form </center></div>
                                    
					<div class="panel-body">
					
                                            <form method="post" action="profile.php">
						<div class="row">
							<div class="col-md-6">
								<font color="white"><label for="f_name">First Name</label>
                                                                <input type="text" id="f_name" name="f_name" class="form-control" required><font>
							</div>
							<div class="col-md-6">
								<label for="f_name">Last Name</label>
								<input type="text" id="l_name" name="l_name"class="form-control" required>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="email">Email</label>
								<input type="email" id="email" name="email"class="form-control" required>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="password">password</label>
								<input type="password" id="password" name="password"class="form-control" required>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="repassword">Re-enter Password</label>
								<input type="password" id="repassword" name="repassword"class="form-control" required>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="mobile">Mobile</label>
                                                                <input type="number" id="mobile" name="mobile"class="form-control" required>
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="address1">Address Line 1</label>
								<input type="text" id="address1" name="address1"class="form-control required">
							</div>
						</div>
						<div class="row">
							<div class="col-md-12">
								<label for="address2">Address Line 2</label>
								<input type="text" id="address2" name="address2"class="form-control required">
							</div>
						</div>
						<p><br/></p>
						<div class="row">
							<div class="col-md-12">
								<input style="float:right; color:white; background: #FDA30E" value="Sign Up" type="button" id="signup_button" name="signup_button" class="btn btn-success btn-lg">
							</div>
						</div>
						</form>
					</div>
					
					<!--<div class="panel-footer">uygftyfjh</div>-->
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
	</div>
         <!--<p class="copy-right">-->
                                            <div class="panel-footer" style="background: #38373C">
                                           <font color="white"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2018 | Developer by Amit Kumar Kushwaha</div></p>
                                        <!--<div class="panel-footer"></div>-->
        
<!--                  #############################################
			
			<div class="clearfix"></div>
			<div class="sign-grds">
				<div class="col-md-4 sign-gd">
					<h4><font color="#0f6ebc">Information</font></h4>
					<ul>
						<li><a href="index.html">Home</a></li>
						<li><a href="mens.html">Men's Wear</a></li>
						<li><a href="womens.html">Women's Wear</a></li>
						<li><a href="electronics.html">Electronics</a></li>
						<li><a href="codes.html">Short Codes</a></li>
						<li><a href="#">Contact</a></li>
					</ul>
				</div>
				
				<div class="col-md-4 sign-gd-two">
					<h4><font color="#0f6ebc">Store Information</font></h4>
					<ul>
						<li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>Address :Sirmour Chock , <span>Rewa City.</span></li>
						<li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>Email : <a href="#">jeansfactoryrewa@gmail.com</a></li>
						<li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>Phone : +91 7974857600 </li>
					</ul>-->
                                       
<!--				</div>
				<div class="col-md-4 sign-gd flickr-post">
					<h4><font color="#0f6ebc">Flickr Posts</font></h4>
					<ul>
						<li><a href="single.html"><img src="images/b15.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/b16.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/b17.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/b18.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/b15.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/b16.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/b17.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/b18.jpg" alt=" " class="img-responsive" /></a></li>
						<li><a href="single.html"><img src="images/b15.jpg" alt=" " class="img-responsive" /></a></li>
					</ul>
                                        
				</div>
                            
				<div class="clearfix"></div>
                                
			</div>
		</div>
		<div class="clearfix"></div>
		
##########################################-->
</body>
</html>
