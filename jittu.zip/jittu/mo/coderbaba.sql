-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 17, 2018 at 05:05 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coderbaba`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `user_id` int(10) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`user_id`, `user_email`, `user_pass`) VALUES
(1, 'shi@gmail.com', 'shi'),
(2, 'lian@gmail.com', 'lian');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
CREATE TABLE IF NOT EXISTS `brands` (
  `brand_id` int(100) NOT NULL AUTO_INCREMENT,
  `brand_title` text NOT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'SamSung'),
(2, 'Apple');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) NOT NULL,
  `product_title` varchar(200) NOT NULL,
  `product_image` varchar(200) NOT NULL,
  `qty` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `total_amt` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `product_title`, `product_image`, `qty`, `price`, `total_amt`) VALUES
(1, 1, '0', 0, 'Samsung Dous 2', 'samsung mobile.jpg', 1, 5000, 5000),
(2, 2, '0', 0, 'iPhone 5s', 'iphone mobile.jpg', 1, 25000, 25000),
(3, 1, '0', 4, 'Kids Fashion Sweater ( à¤•à¤¿à¤¡à¥à¤¸ à¤«à¥ˆà¤¶à¤¨  à¤¸à¥à¤µà¥‡à¤Ÿà¤°)', '3.jpg', 1, 500, 500),
(4, 2, '0', 4, 'kids Party Wear ( à¤•à¤¿à¤¡à¥à¤¸ à¤ªà¤¾à¤°à¥à¤Ÿà¥€  à¤µà¤¿à¤¯à¤° )', 'c1.jpg', 1, 350, 350),
(5, 2, '0', 6, 'kids Party Wear ( à¤•à¤¿à¤¡à¥à¤¸ à¤ªà¤¾à¤°à¥à¤Ÿà¥€  à¤µà¤¿à¤¯à¤° )', 'c1.jpg', 1, 350, 350),
(6, 6, '0', 6, 'jeans cloth ( à¤œà¥€à¤¨à¥à¤¸ à¤•à¥à¤²à¥‰à¤¥ )', 'j25.jpg', 1, 700, 700),
(7, 4, '0', 6, 'Penta Thread ( à¤ªà¥‡à¤‚à¤Ÿà¤¾ à¤§à¤¾à¤—à¤¾ )', 'b16.jpg', 1, 200, 200),
(8, 8, '0', 6, 'Detail of product (à¤¡à¤¿à¤Ÿà¥‡à¤²  à¤‘à¥ž  à¤ªà¥à¤°à¥‹à¤¡à¤•à¥à¤Ÿ )', 'aa.jpg', 1, 0, 0),
(10, 2, '0', 8, 'kids Party Wear ( à¤•à¤¿à¤¡à¥à¤¸ à¤ªà¤¾à¤°à¥à¤Ÿà¥€  à¤µà¤¿à¤¯à¤° )', 'c1.jpg', 1, 350, 350),
(11, 3, '0', 8, 'Ladies Wear Fashion ( à¤²à¥‡à¤¡à¥€à¤œ à¤µà¤¿à¤¯à¤°  à¤«à¥ˆà¤¶à¤¨ )', 'w25.jpg', 1, 600, 600),
(12, 6, '0', 8, 'jeans cloth ( à¤œà¥€à¤¨à¥à¤¸ à¤•à¥à¤²à¥‰à¤¥ )', 'j25.jpg', 1, 700, 700),
(13, 5, '0', 8, 'Moon Thread ( à¤®à¥‚à¤¨ à¤§à¤¾à¤—à¤¾ )', 'dhaga.jpg', 1, 10000, 10000),
(21, 1, '0', 25, 'Kids Fashion Sweater ( à¤•à¤¿à¤¡à¥à¤¸ à¤«à¥ˆà¤¶à¤¨ à¤¸à¥à¤µà¥‡à¤Ÿà¤°)', 'b17.jpg', 1, 500, 500),
(22, 5, '0', 25, 'Moon Thread ( à¤®à¥‚à¤¨ à¤§à¤¾à¤—à¤¾ )', 'dhaga.jpg', 1, 4, 4),
(42, 4, '0', 32, 'Redmi Note 5 Pro', 'Redmi Note 5 Pro.jpeg', 1, 14287, 14287);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `cat_id` int(100) NOT NULL AUTO_INCREMENT,
  `cat_title` text NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(2, 'Micromax'),
(3, 'Samsung'),
(4, 'Intex'),
(8, 'Karbonn'),
(9, 'Lava');

-- --------------------------------------------------------

--
-- Table structure for table `ord`
--

DROP TABLE IF EXISTS `ord`;
CREATE TABLE IF NOT EXISTS `ord` (
  `order_id` varchar(100) NOT NULL,
  `qty` varchar(100) NOT NULL,
  `product_id` varchar(100) NOT NULL,
  `user_id` varchar(100) NOT NULL,
  `trx_id` varchar(100) NOT NULL,
  `p_status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ord`
--

INSERT INTO `ord` (`order_id`, `qty`, `product_id`, `user_id`, `trx_id`, `p_status`) VALUES
('1', '5', '412', '45', '\\\r\n', '\r\n45');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `u_id` int(200) NOT NULL,
  `p_id` int(200) NOT NULL,
  `qty` int(10) NOT NULL,
  `o_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `u_id`, `p_id`, `qty`, `o_date`) VALUES
(17, 22, 3, 1, '2018-10-11 03:25:19'),
(18, 22, 4, 1, '2018-10-11 03:26:47'),
(16, 22, 2, 1, '2018-10-11 03:25:19'),
(4, 22, 2, 1, '2018-10-11 01:32:53'),
(6, 22, 2, 1, '2018-10-11 01:46:17'),
(7, 22, 3, 1, '2018-10-11 01:46:17'),
(8, 22, 2, 1, '2018-10-11 01:57:20'),
(9, 22, 3, 1, '2018-10-11 01:57:20'),
(27, 26, 8, 1, '2018-10-11 17:56:18'),
(32, 27, 3, 1, '2018-10-11 21:34:58'),
(26, 26, 2, 1, '2018-10-11 17:55:48'),
(29, 27, 2, 5, '2018-10-11 18:26:48'),
(28, 27, 1, 1, '2018-10-11 18:24:32'),
(59, 32, 4, 1, '2018-10-17 04:08:16'),
(34, 27, 1, 1, '2018-10-11 21:36:32'),
(33, 27, 8, 1, '2018-10-11 21:34:58'),
(21, 24, 10, 1, '2018-10-11 12:26:17'),
(22, 24, 20, 1, '2018-10-11 12:26:17'),
(23, 24, 69, 1, '2018-10-11 12:26:17'),
(35, 27, 2, 1, '2018-10-11 21:36:32'),
(36, 27, 3, 1, '2018-10-11 21:36:32'),
(37, 27, 6, 1, '2018-10-11 21:36:32'),
(38, 27, 1, 1, '2018-10-11 21:39:23'),
(39, 27, 2, 1, '2018-10-11 21:39:23'),
(40, 27, 3, 1, '2018-10-11 21:39:23'),
(41, 27, 6, 1, '2018-10-11 21:39:23'),
(42, 27, 5, 1, '2018-10-11 21:39:23'),
(43, 27, 1, 1, '2018-10-11 21:44:24'),
(44, 27, 2, 1, '2018-10-11 21:44:24'),
(45, 27, 3, 1, '2018-10-11 21:44:24'),
(46, 27, 6, 1, '2018-10-11 21:44:24'),
(47, 27, 5, 1, '2018-10-11 21:44:24'),
(48, 29, 10, 1, '2018-10-13 01:42:59'),
(49, 31, 5, 1, '2018-10-16 16:09:16'),
(50, 31, 2, 1, '2018-10-16 16:16:11'),
(51, 31, 9, 1, '2018-10-16 16:18:40'),
(52, 31, 9, 1, '2018-10-16 16:20:48'),
(53, 31, 9, 1, '2018-10-16 16:21:16'),
(54, 31, 9, 1, '2018-10-16 16:29:27'),
(55, 31, 10, 1, '2018-10-16 16:29:27'),
(56, 29, 2, 1, '2018-10-16 16:31:03'),
(57, 29, 3, 1, '2018-10-16 16:31:03'),
(58, 29, 5, 1, '2018-10-16 16:31:03'),
(60, 32, 3, 1, '2018-10-17 04:08:16'),
(61, 32, 2, 1, '2018-10-17 04:08:16');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(100) NOT NULL AUTO_INCREMENT,
  `product_cat` int(100) NOT NULL,
  `product_brand` int(100) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES
(2, 0, 0, 'Samsung Galaxy J6', 12315, 'mobile', 's1.jpeg', 'Samsung Galaxy J6'),
(3, 0, 0, 'Vivo V9', 17805, 'mobile', 'Vivo V9.jpeg', 'Vivo V9'),
(4, 0, 0, 'Redmi Note 5 Pro', 14287, 'Redmi Note 5 Pro', 'Redmi Note 5 Pro.jpeg', 'Redmi Note 5 Pro'),
(5, 0, 0, 'Oppo F7', 18950, 'Oppo F7', 'Oppo F7.jpeg', 'Oppo F7'),
(6, 0, 0, 'Oneplus 6', 34000, 'Oneplus 6', 'Oneplus 6.jpg', 'Oneplus 6'),
(7, 0, 0, 'Samsung A6 Plus', 23600, 'Samsung A6 Plus', 'Samsung A6 Plus.jpeg', 'Samsung A6 Plus'),
(8, 0, 0, 'Vivo Y83', 14000, 'Vivo Y83', 'Vivo Y83.jpeg', 'Vivo Y83'),
(9, 0, 0, 'Motorola Moto G6 ', 15000, 'Motorola Moto G6 ', 'Motorola Moto G6.jpeg', 'Motorola Moto G6 '),
(10, 2, 0, 'Micromax Canvas 5 Lite Q463 ', 5000, 'Micromax Canvas 5 Lite Q463 ', 'Micromax Canvas 5 Lite Q463.jpeg', 'Micromax Canvas 5 Lite Q463 '),
(11, 3, 1, 'Samsung Galaxy J7 Duo', 12999, 'Samsung Galaxy J7 Duo', 'Samsung Galaxy J7 Duo.jpeg', 'Samsung Galaxy J7 Duo');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

DROP TABLE IF EXISTS `user_info`;
CREATE TABLE IF NOT EXISTS `user_info` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(8, 'o', 'j`', 'a@gmail.com', 'aab3238922bcc25a6f606eb525ffdc56', '58854', 'yt', 'tyd'),
(10, 'g', 'h', 'a@d.v', 'aab3238922bcc25a6f606eb525ffdc56', '44', 'hjq', 'lk'),
(17, 'd', 's', 'e@gmail.com', 'sdfghjkl[poiuy', '4152637485', 'rtghjk', 'efghjkl'),
(18, 'jk', 'jk', 'er@gmail.com', 'ijuhylokiu', '4152637485', 'lkjh', 'lkjh'),
(30, 'ad', 'd', 'ak@gmail.com', '12345678', '8085636040', ';lkjh', 'ghjk'),
(31, 'ad', 'd', 'ad@gmail.com', '12345678', '7000610729', ';lkjh', 'ghjk'),
(32, 'm', 'ghj', 'm@gmail.com', '12345678', '7000610729', 'fghjk', 'fghj');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
