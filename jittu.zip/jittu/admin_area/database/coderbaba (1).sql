-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 25, 2018 at 11:27 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coderbaba`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
CREATE TABLE IF NOT EXISTS `admins` (
  `user_id` int(10) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`user_id`, `user_email`, `user_pass`) VALUES
(1, 'shi@gmail.com', 'shi'),
(2, 'lian@gmail.com', 'lian');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
CREATE TABLE IF NOT EXISTS `brands` (
  `brand_id` int(100) NOT NULL AUTO_INCREMENT,
  `brand_title` text NOT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(1, 'Vimal'),
(2, 'Moon Thread'),
(3, 'Penta Thread'),
(4, 'Amito Thread');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `p_id` int(10) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(10) NOT NULL,
  `product_title` varchar(200) NOT NULL,
  `product_image` varchar(200) NOT NULL,
  `qty` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `total_amt` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `product_title`, `product_image`, `qty`, `price`, `total_amt`) VALUES
(1, 1, '0', 0, 'Samsung Dous 2', 'samsung mobile.jpg', 1, 5000, 5000),
(2, 2, '0', 0, 'iPhone 5s', 'iphone mobile.jpg', 1, 25000, 25000),
(3, 1, '0', 4, 'Kids Fashion Sweater ( à¤•à¤¿à¤¡à¥à¤¸ à¤«à¥ˆà¤¶à¤¨  à¤¸à¥à¤µà¥‡à¤Ÿà¤°)', '3.jpg', 1, 500, 500),
(4, 2, '0', 4, 'kids Party Wear ( à¤•à¤¿à¤¡à¥à¤¸ à¤ªà¤¾à¤°à¥à¤Ÿà¥€  à¤µà¤¿à¤¯à¤° )', 'c1.jpg', 1, 350, 350);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `cat_id` int(100) NOT NULL AUTO_INCREMENT,
  `cat_title` text NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(2, 'Ladies Wears (à¤²à¥‡à¤¡à¥€à¤œ  à¤µà¤¿à¤¯à¤°)'),
(3, 'Mens Wear(à¤®à¥‡à¤‚à¤¸ à¤µà¤¿à¤¯à¤°)'),
(4, 'Kids Wear(à¤•à¤¿à¤¡à¥à¤¸  à¤µà¤¿à¤¯à¤°)'),
(8, 'Silai All Items(à¤¸à¤¿à¤²à¤¾à¤ˆ à¤•à¥‡ à¤¸à¤­à¥€ à¤¸à¤¾à¤®à¤¾à¤¨ )'),
(9, 'Lining(à¤…à¤¸à¥à¤¤à¤°)'),
(10, 'phal(à¤«à¤¾à¤²)'),
(11, 'Blouse Peace ( à¤¬à¥à¤²à¤¾à¤‰à¤œ à¤ªà¥€à¤¸ )'),
(12, 'needle , Thread ( à¤¸à¥à¤ˆ, à¤§à¤¾à¤—à¤¾ )'),
(13, ' Buckram ,button ( à¤¬à¤•à¤°à¤®, à¤¬à¤Ÿà¤¨  )'),
(14, 'Lease ( à¤²à¥‡à¤¸ )');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(100) NOT NULL AUTO_INCREMENT,
  `product_cat` int(100) NOT NULL,
  `product_brand` int(100) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` int(100) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_cat`, `product_brand`, `product_title`, `product_price`, `product_desc`, `product_image`, `product_keywords`) VALUES
(1, 0, 0, 'Kids Fashion Sweater ( à¤•à¤¿à¤¡à¥à¤¸ à¤«à¥ˆà¤¶à¤¨  à¤¸à¥à¤µà¥‡à¤Ÿà¤°)', 500, 'this is the best for kids', '3.jpg', 'Fashion Sweater'),
(2, 0, 0, 'kids Party Wear ( à¤•à¤¿à¤¡à¥à¤¸ à¤ªà¤¾à¤°à¥à¤Ÿà¥€  à¤µà¤¿à¤¯à¤° )', 350, 'this is for kids', 'c1.jpg', 'à¤•à¤¿à¤¡à¥à¤¸ à¤ªà¤¾à¤°à¥à¤Ÿà¥€  à¤µà¤¿à¤¯à¤° '),
(3, 0, 0, 'Ladies Wear Fashion ( à¤²à¥‡à¤¡à¥€à¤œ à¤µà¤¿à¤¯à¤°  à¤«à¥ˆà¤¶à¤¨ )', 600, 'à¤²à¥‡à¤¡à¥€à¤œ à¤µà¤¿à¤¯à¤°  à¤«à¥ˆà¤¶à¤¨ ', 'w25.jpg', 'à¤²à¥‡à¤¡à¥€à¤œ à¤µà¤¿à¤¯à¤°  à¤«à¥ˆà¤¶à¤¨ '),
(4, 0, 0, 'Penta Thread ( à¤ªà¥‡à¤‚à¤Ÿà¤¾ à¤§à¤¾à¤—à¤¾ )', 200, 'à¤ªà¥‡à¤‚à¤Ÿà¤¾ à¤§à¤¾à¤—à¤¾ ', 'b16.jpg', 'à¤ªà¥‡à¤‚à¤Ÿà¤¾ à¤§à¤¾à¤—à¤¾ '),
(5, 0, 0, 'Moon Thread ( à¤®à¥‚à¤¨ à¤§à¤¾à¤—à¤¾ )', 10000, 'à¤®à¥‚à¤¨ à¤§à¤¾à¤—à¤¾ ', 'dhaga.jpg', 'à¤®à¥‚à¤¨ à¤§à¤¾à¤—à¤¾ '),
(6, 0, 0, 'jeans cloth ( à¤œà¥€à¤¨à¥à¤¸ à¤•à¥à¤²à¥‰à¤¥ )', 700, 'à¤œà¥€à¤¨à¥à¤¸ à¤•à¥à¤²à¥‰à¤¥    ', 'j25.jpg', 'à¤œà¥€à¤¨à¥à¤¸ à¤•à¥à¤²à¥‰à¤¥    '),
(7, 0, 0, 'lining ( à¤…à¤¸à¥à¤¤à¤° )', 14, 'lining ( à¤…à¤¸à¥à¤¤à¤° )', 'd4.jpg', 'lining ( à¤…à¤¸à¥à¤¤à¤° )'),
(8, 0, 0, 'Detail of product (à¤¡à¤¿à¤Ÿà¥‡à¤²  à¤‘à¥ž  à¤ªà¥à¤°à¥‹à¤¡à¤•à¥à¤Ÿ )', 0, 'Detail of product (à¤¡à¤¿à¤Ÿà¥‡à¤²  à¤‘à¥ž  à¤ªà¥à¤°à¥‹à¤¡à¤•à¥à¤Ÿ )', 'aa.jpg', 'Detail of product (à¤¡à¤¿à¤Ÿà¥‡à¤²  à¤‘à¥ž  à¤ªà¥à¤°à¥‹à¤¡à¤•à¥à¤Ÿ )'),
(9, 0, 0, 'Blouse (à¤¬à¥à¤²à¤¾à¤‰à¤œ )', 200, 'Blouse (à¤¬à¥à¤²à¤¾à¤‰à¤œ )', 'b17.jpg', 'Blouse (à¤¬à¥à¤²à¤¾à¤‰à¤œ )'),
(10, 2, 6, 'Red Ladies dress', 1000, 'red dress for girls', 'red dress.jpg', 'red dress '),
(11, 0, 0, 'Ladies wear ( à¤²à¥‡à¤¡à¥€à¤œ  à¤µà¤¿à¤¯à¤° )', 700, 'Ladies wear ( à¤²à¥‡à¤¡à¥€à¤œ  à¤µà¤¿à¤¯à¤° )', 'w9.jpg', 'Ladies wear ( à¤²à¥‡à¤¡à¥€à¤œ  à¤µà¤¿à¤¯à¤° )'),
(12, 0, 0, 'Ladies Casual Cloths', 1500, 'ladies casual summer two colors pleted', 'w11.jpg', 'girl dress cloths casual'),
(13, 2, 6, 'SpringAutumnDress', 1200, 'girls dress', 'Spring-Autumn-Winter-Young-Ladies-Casual-Wool-Dress-Women-s-One-Piece-Dresse-Dating-Clothes-Medium.jpg_640x640.jpg', 'girl dress'),
(14, 0, 0, 'Ladies wear ( à¤²à¥‡à¤¡à¥€à¤œ  à¤µà¤¿à¤¯à¤° )', 1400, 'Ladies wear ( à¤²à¥‡à¤¡à¥€à¤œ  à¤µà¤¿à¤¯à¤° )', 'w19.jpg', 'Ladies wear ( à¤²à¥‡à¤¡à¥€à¤œ  à¤µà¤¿à¤¯à¤° )'),
(15, 2, 6, 'Formal Look', 1500, 'girl dress', 'shutterstock_203611819.jpg', 'ladies wears dress girl'),
(16, 3, 6, 'Sweter for men', 600, '2012-Winter-Sweater-for-Men-for-better-outlook', '2012-Winter-Sweater-for-Men-for-better-outlook.jpg', 'black sweter cloth winter'),
(17, 3, 6, 'Gents formal', 1000, 'gents formal look', 'gents-formal-250x250.jpg', 'gents wear cloths'),
(19, 3, 6, 'Formal Coat', 3000, 'ad', 'images (1).jpg', 'coat blazer gents'),
(20, 3, 6, 'Mens Sweeter', 1600, 'jg', 'Winter-fashion-men-burst-sweater.png', 'sweeter gents '),
(21, 3, 6, 'T shirt', 800, 'ssds', 'IN-Mens-Apparel-Voodoo-Tiles-09._V333872612_.jpg', 'formal t shirt black'),
(22, 4, 6, 'Yellow T shirt ', 1300, 'yello t shirt with pant', '1.0x0.jpg', 'kids yellow t shirt'),
(23, 4, 6, 'Girls cloths', 1900, 'sadsf', 'GirlsClothing_Widgets.jpg', 'formal kids wear dress'),
(24, 0, 0, 'Blue T shirt', 700, 'g', 'w9.jpg', 'kids dress'),
(25, 4, 6, 'Yellow girls dress', 750, 'as', 'images (3).jpg', 'yellow kids dress'),
(26, 4, 6, 'Skyblue dress', 650, 'nbk', 'kids-wear-121.jpg', 'skyblue kids dress'),
(27, 4, 6, 'Formal look', 690, 'sd', 'image28.jpg', 'formal kids dress'),
(35, 6, 0, 'Vaccum Cleaner', 6000, 'Vaccum Cleaner', 'images (2).jpg', 'Vaccum Cleaner'),
(37, 6, 5, 'LED TV', 20000, 'LED TV', 'images (4).jpg', 'led tv lg'),
(38, 0, 0, 'Ladies wear ( à¤²à¥‡à¤¡à¥€à¤œ  à¤µà¤¿à¤¯à¤° )', 600, 'Ladies wear ( à¤²à¥‡à¤¡à¥€à¤œ  à¤µà¤¿à¤¯à¤° )', 'w9.jpg', 'Ladies wear ( à¤²à¥‡à¤¡à¥€à¤œ  à¤µà¤¿à¤¯à¤° )'),
(40, 2, 6, 'Formal girls dress', 3000, 'Formal girls dress', 'girl-walking.jpg', 'ladies'),
(41, 10, 1, 'Phal ()', 12, '12 / peace \r\nsize 2.25 Meter \r\nVimal Top  ', 'baa2.jpg', 'Phal'),
(42, 10, 1, 'Phal Vimal Top', 12, '12/Pease \r\nVimal Top\r\n', 'b18.jpg', 'Phal'),
(43, 12, 2, 'Thread  Moon ( à¤§à¤¾à¤—à¤¾ à¤®à¥‚à¤¨ )', 5, 'Thread Moon(à¤§à¤¾à¤—à¤¾ à¤®à¥‚à¤¨)\r\n5/ peace', 'moon1.jpg', 'Thread  Moon ( à¤§à¤¾à¤—à¤¾ à¤®à¥‚à¤¨ )'),
(44, 12, 3, 'dhaga', 20, 'hguik,', '1.jpg', 'dhaga'),
(45, 13, 2, 'baton', 20, 'ugiuk', '4.jpg', 'jhv');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

DROP TABLE IF EXISTS `user_info`;
CREATE TABLE IF NOT EXISTS `user_info` (
  `user_id` int(10) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(1, 'demo', 'demo', 'demo@gmal.com', '12345', '123456789', 'Kolkata', 'VIP Road'),
(2, 'Rizwan', 'Khan', 'rizwankhan.august16@gmail.com', '25f9e794323b453885f5181f1b624d0b', '9832268432', 'Hutton Road', 'Kolkata'),
(3, 'Rizwan', 'Khan', 'salmankhan@gmail.com', '25f9e794323b453885f5181f1b624d0b', '8389080182', 'Hutton Road', 'Asansol'),
(4, 'ak', 'kk', 'h@g.com', 'c20ad4d76fe97759aa27a0c99bff6710', '52522', ';llk', 'kl');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
