<?php
include("includes/db.php");
if(isset($_GET['id'])){
    $delete_id = $_GET['id'];
    $run_delete = mysqli_query($con,"delete from orders where id='$delete_id'");
    if($run_delete){
       echo "<script>alert('A order has been deleted!');</script>";
	   echo "<script>window.open('index.php?view_orders','_self');</script>";
    }
}
?>