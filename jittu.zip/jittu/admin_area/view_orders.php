<table width="795" align="center" bgcolor="#FDA30E"> 

	
	<tr align="center">
		<td colspan="6"><h2>View all orders here</h2></td>
	</tr>
	
	<tr align="center" bgcolor="#38373C">
       
		<th> <font color="white">S.N</font></th>
		<th> <font color="white">Customer Email</font></th>
		<th> <font color="white">Product (S)</font></th>
		<th> <font color="white">Quantity</font></th>
		<!--<th>Invoice No</th>-->
		<th> <font color="white">Order Date</font></th>
                <th> <font color="white">Delete</font></th>
	</tr>
	<?php 
	include("includes/db.php");
	$get_order = "select * from orders";
	$run_order = mysqli_query($con, $get_order); 
	$i = 0;
	while ($row_order=mysqli_fetch_array($run_order)){
		$order_id = $row_order['id'];
		$qty = $row_order['qty'];
		$pro_id = $row_order['p_id'];
		$c_id = $row_order['u_id'];
//		$invoice_no = $row_order['trx_id'];
		$order_date = $row_order['o_date'];
		$i++;
		
		$get_pro = "select * from products where product_id='$pro_id'";
		$run_pro = mysqli_query($con, $get_pro); 
		
		$row_pro=mysqli_fetch_array($run_pro); 
		
		$pro_image = $row_pro['product_image']; 
		$pro_title = $row_pro['product_title'];
		
		$get_c = "select * from user_info where user_id='$c_id'";
		$run_c = mysqli_query($con, $get_c); 
		
		$row_c=mysqli_fetch_array($run_c); 
		
		$c_email = $row_c['email'];
	
	?>
	<tr align="center">
		<td><?php echo $i;?></td>
		<td><?php echo $c_email; ?></td>
		<td>
		<?php echo $pro_title;?><br>
		<img src="product_images/<?php echo $pro_image;?>" width="50" height="50" />
		</td>
		<td><?php echo $qty;?></td>
		<!--<td><?php // echo $invoice_no;?></td>-->
		<td><?php echo $order_date;?></td>
                <td><a href="d_ord.php?id=<?php echo $order_id;?>">Delete</a></td>
	
	</tr>
	<?php } ?>
</table>